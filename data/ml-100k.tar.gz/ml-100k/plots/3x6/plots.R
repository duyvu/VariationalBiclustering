rm(list=ls())

numRows = 943
numCols = 1682

edges = read.table("Y.txt")

numRowClusters = 3
z = read.table(file="Rows.txt",sep=" ")
z = z[,1:3]
z = as.vector(apply(z, 1, which.max))

rowParams = read.table("RowParams.txt",sep=" ")

rowOrdering = rank(rowParams)
for (i in 1:length(z))
	z[i] = rowOrdering[z[i]]

reRowParams = rowParams
for (i in 1:length(reRowParams))
	reRowParams[rowOrdering[i]] = rowParams[i]

rowClusterSizes = matrix(0,nrow=1,ncol=numRowClusters)
for (k in 1:numRowClusters)
	rowClusterSizes[k] = sum(z==k)

numColClusters = 6
w = read.table(file="Cols.txt",sep=" ")
w = w[,1:6]
w = as.vector(apply(w, 1, which.max))

colParams = read.table("ColParams.txt",sep=" ")

colOrdering = rank(colParams)
for (i in 1:length(w))
	w[i] = colOrdering[w[i]]

reColParams = colParams
for (i in 1:length(reColParams))
	reColParams[colOrdering[i]] = colParams[i]

colClusterSizes = matrix(0,nrow=1,ncol=numColClusters)
for (k in 1:numColClusters)
	colClusterSizes[k] = sum(w==k)

density = matrix(nrow=numRowClusters,ncol=numColClusters,0)
iClass = z[edges[,1] + 1]
jClass = w[edges[,2] + 1]

for (k in 1:numRowClusters) 
	for (l in 1:numColClusters)
		density[k,l] = sum(iClass == k & jClass == l)

for (k in 1:numRowClusters) {
	for (l in 1:numColClusters) {
		if (rowClusterSizes[k] > 0 && colClusterSizes[l] > 0)
			density[k,l] = density[k,l] / (rowClusterSizes[k]*colClusterSizes[l])
	}
}

library(sna)

postscript(file=paste("Density-100K-MovieLens-",numRowClusters,"x",numColClusters,".ps",sep=""))
plot.sociomatrix(density, diaglab=TRUE, main=paste("Density of 100K MovieLens with ", numRowClusters,"x",numColClusters," Blocks",sep=""),labels=list(paste(rowClusterSizes,"\n(",round(reRowParams,2),")",sep=""),paste(colClusterSizes,"\n(",round(reColParams,2),")",sep="")), xlab="Movies", ylab="Users")
dev.off()

Y = matrix(0, nrow=numRows, ncol=numCols)
for (k in 1:dim(edges)[1]) {
	i = edges[k,1] + 1
	j = edges[k,2] + 1
	Y[i,j]  = 1
}

pdf("OriginalMap.pdf")
image(t(Y), asp=numRows/numCols, yaxt="n", xaxt="n", frame.plot=FALSE)
dev.off()


rowPerm = order(z, decreasing=TRUE)
rY = Y[rowPerm,]

colPerm = order(w, decreasing=FALSE)
crY = rY[,colPerm]

pdf("ClusteredMap.pdf")
image(t(crY), asp=numRows/numCols, yaxt="n", xaxt="n", frame.plot=FALSE)
dev.off()

