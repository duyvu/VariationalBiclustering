ratings = read.table("u.data")

data = ratings[,1:2]
data = data - 1
ratingFile = "Y.txt"
write.table(data, ratingFile, col.names=FALSE, row.names=FALSE)

#fConn = file(ratingFile, 'r+')
#Lines = readLines(fConn)
#firstLines = paste(943, 1682, 100000, sep="\n")
#writeLines(rbind(firstLines, Lines), con = fConn)

users = read.table("u.user", sep="|")
userData = users[,2:3]
write.table(userData, "RowCov.txt", col.names=FALSE, row.names=FALSE)

movies = read.table("ColCov.cvs",sep="|")
write.table(movies, "ColCov.txt", col.names=FALSE, row.names=FALSE)
