data = read.table("ColCov18.txt", skip=1)
data = data[,2:19]
write.table(data, file="ColCov18.txt", row.names=FALSE, col.names=FALSE)
