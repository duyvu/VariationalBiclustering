rm(list=ls())

numRows = 899
numCols = 552

edges = read.table("messages.txt",skip=3)
Y = matrix(0, nrow=numRows, ncol=numCols)
for (k in 1:dim(edges)[1]) {
	i = edges[k,1] + 1
	j = edges[k,2] + 1
	Y[i,j]  = edges[k,3]
}

aspect=2*numRows/numCols

pdf("OriginalMap.pdf")
image(log(t(Y)), asp=aspect, yaxt="n", xaxt="n", frame.plot=FALSE)
dev.off()

numRowClusters = 4
z = read.table(file="Rows.txt",sep=" ")
z = z[,1:numRowClusters]
z = as.vector(apply(z, 1, which.max))

rowClusterSizes = matrix(0,nrow=1,ncol=numRowClusters)
for (k in 1:numRowClusters)
	rowClusterSizes[k] = sum(z==k)

numColClusters = 4
w = read.table(file="Cols.txt",sep=" ")
w = w[,1:numColClusters]
w = as.vector(apply(w, 1, which.max))

colClusterSizes = matrix(0,nrow=1,ncol=numColClusters)
for (k in 1:numColClusters)
	colClusterSizes[k] = sum(w==k)

pdf("Means.pdf")
params = as.matrix(read.table("Params.txt"))
params = params[c(3,2,1),]
image(t(params), yaxt="n", xaxt="n", frame.plot=FALSE)
dev.off()

rowPerm = order(z, decreasing=TRUE)
rY = Y[rowPerm,]

colPerm = order(w, decreasing=TRUE)
crY = rY[,colPerm]
crY = as.matrix(crY)

crY[rowClusterSizes[4],] = 10
crY[rowClusterSizes[3] + rowClusterSizes[4],] = 10
crY[rowClusterSizes[2] + rowClusterSizes[3] + rowClusterSizes[4],] = 10

crY[,colClusterSizes[4]] = 10
crY[,colClusterSizes[3] + colClusterSizes[4]] = 10
crY[,colClusterSizes[2] + colClusterSizes[3] + colClusterSizes[4]] = 10

pdf("ClusteredMap.pdf")
image(log(t(crY)), asp=aspect, yaxt="n", xaxt="n", frame.plot=FALSE)
dev.off()

choose <- function(w, params) {
	return(params[w])
}

meanY = Y
params = as.matrix(read.table("Params.txt"))
for (i in 1:numRows)
	meanY[i,] = lapply(w,choose,params[z[i],])
meanY = meanY[rowPerm,]
meanY = meanY[,colPerm]
pdf("MeanClusteredMap.pdf")
image(meanY, asp=aspect, yaxt="n", xaxt="n", frame.plot=FALSE)
dev.off()


