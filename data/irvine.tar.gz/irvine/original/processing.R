data = read.table("messages.data")
dim(data)
data[,1] = data[,1] - 1 
data[,2] = data[,2] - 1 
write.table(data,"messages.txt",sep="\t",col.names=FALSE,row.names=FALSE)

data = read.table("characters.data")
dim(data)
data[,1] = data[,1] - 1 
data[,2] = data[,2] - 1 
write.table(data,"characters.txt",sep="\t",col.names=FALSE,row.names=FALSE)


